# Roadmap de Produção — dois trilhos

> Atualizado no dia em que este doc nasceu: o app funciona 100% em modo demo (dados no
> navegador). "Produção" tem exatamente **um** pré-requisito de código (Fase A) — o resto
> é conta em painel e conteúdo gravado. Nada aqui promete o que o código não faz.

---

## TRILHO 1 — Deploy real (Supabase + Vercel)

### Fase A · Camada de dados Supabase (código — é o trabalho grande, e é MEU)

Hoje `src/lib/supabase.ts` só detecta env (`isDemoMode()`). Precisa escrever a camada real:

| # | Passo | Critério de pronto |
|---|---|---|
| A1 | Instalar `@supabase/supabase-js`; criar client com `getSession()` + listener de sessão | login demo e real coexistem via env |
| A2 | Services de leitura (content, mentor, library, genres) → `supabase.from()` com os MESMOS nomes de tabela do schema | páginas de catálogo idênticas em modo real |
| A3 | Auth → `signUp/signInWithPassword/resetPasswordForEmail` + `profiles` (remove o hashPassword local) | contas com e-mail de confirmação |
| A4 | Escrita do aluno → progress, finish, studio, community, certificates, lgpd (tudo async; UI ganha spinners de verdade) | dois navegadores logados em contas diferentes vêem progressos independentes; RLS bloqueia leitura cruzada (testar!) |
| A5 | Gamificação derivada → métricas via queries agregadas (hoje `raw()` varre arrays) | dashboard carrega < 300 ms com 10k linhas |
| A6 | Uploads reais → bucket `track-audio` (signed URL no player do portfólio/feedback) + `lesson-video` se optar por vídeo próprio | arrastar WAV no analyzer do dispositivo continua local; subir faixa publica com áudio tocável |
| A7 | Tests: suíte atual roda na camada local (fallback); + testes de contrato da camada supabase com mock (`nock`/`msw` style) | `vitest run` verde nos dois modos |

Ordem de entrega: A1→A3 primeiro (conta + catálogo + progresso = MVP multiusuário útil), depois A4→A7.
**Quanto:** várias sessões de trabalho no sandbox; eu executo por fase, cada uma commitada com testes verdes.

### Fase B · Painéis (30–60 min — é TODO SEU)

Checklist exato está em `docs/DEPLOY.md` §1–2. Resumo dos cliques:
1. supabase.com → New Project → SQL Editor → colar `supabase/schema.sql` inteiro → Run
2. Auth → Providers Email on; Site URL/Redirects = domínio Vercel final
3. Storage → buckets `library` / `track-audio` / `avatars` (+ `lesson-video` se próprio)
4. vercel.com → New Project → importar `sonora-lab` → envs `VITE_SUPABASE_URL` + `VITE_SUPABASE_ANON_KEY` → deploy
5. DNS/domínio próprio (a brand não fica fixa no código: trocar `src/config/brand.ts` + gerar `public/sitemap.xml` com o domínio novo — é arquivo estático, 2 min)

### Fase C · Dinheiro de verdade (depois do primeiro aluno)
- PSP (Stripe/MP/Asaas) + webhooks serverless (`api/`) → ativa `subscriptions` reais (o fluxo demo já emula o ciclo completo)
- Edge Function `mentor` com provider externo (arquitetura anti-alucinação pronta em `docs/AI_PROVIDER.md`)
- Marketplace/B2B: modelado no schema quando a feature nascer (nunca antes — evita tabela fantasma)

**Deploy intermediário válido hoje:** Vercel SEM Supabase = site público demo. As páginas de marketing/SEO funcionam perfeitamente e dá pra coletar lista de espera. Só não há conta compartilhada (cada visitante tem seu demo local). Se quiser, eu preparo o botão "entrar na lista" gravando em tabela própria — 20 min de trabalho.

---

## TRILHO 2 — Conteúdo (vídeos + cursos avançados)

### Pipeline de gravação (por aula)
- **Formato:** OBS, screen capture 1080p/60fps (DAAM exige fluidez de mouse), mic decente, aula-alvo **3–6 min**
- **Estrutura fixa (5 beats):** cold open com o objetivo da aula → conceito DAW-independente → caminho na DAW (aqui vale o carimbo de versão!) → prática na sua track → desafio+preview da próxima
- **Publicação (2 opções, a primeira é de longe a mais barata):**
  - A) **YouTube unlisted** → cola a URL no campo `videoUrl` do admin. Zero custo de storage, player embutido já funciona, dá pra trocar o vídeo sem redeploy.
  - B) Supabase Storage `lesson-video` → experiência white-label, mas storage+egress pagos; fica pra Fase C (A6).
- **Versionamento:** se a release da DAW mudar a UI usada no vídeo, **só regrava a aula específica**; teorias não têm carimbo de versão de interface porque não dependem dela
- **Nomenclatura:** `curso-slug-lNN.mp4` → a aula X do CMS é sempre mapeável de memória

### Ordem de gravação com melhor ROI
1. **Curso 01 — Produção do Zero** inteiro (é a escada do funil: as amostras Free dele são o primeiro contato)
2. Projetos 01–03 (são os exercícios que seguram retenção)
3. Mix/MASTER nos cursos 07–08 (conteúdo que mais dá orgulho de mostrar)
4. Academias por DAW depois (público segmentado, maior ticket)

### Cursos avançados — catálogo que EU posso escrever agora (mesma qualidade do núcleo: módulos + aulas + quizzes + projetos)

| # | Curso | Ângulo | Gate de versão DAW? |
|---|---|---|---|
| 10 | **Vocais na Música Eletrônica** | captação legal, sibilância, formant, tune sem boneco, vocal-chop resampling | só na aula de DAW-edit |
| 11 | **Lançamento & Distribuição** | metadados, ISRC/UPC, distribuidoras, ECAD/associação, Spotify for Artists, plano de 12 semanas pré-lançamento | **não** (processual) |
| 12 | **Live Set & Produção Híbrida** | Ableton como instrumento: sessões, stems, loop-bridge, gravação do set | **sim** (Ableton) |
| 13 | **Sistema Anti-Loop** | terminar música como comportamento: prazos, restrição de palette, peer review na comunidade, gestão de WIP | não |

Mais duas trilhas de gênero via arquitetura já aberta (Minimal/Deep Tech e Progressive Psy) — geradas como os 14 existentes.

**Combustor de confiança (não pular):** nos cursos 10–13 vale a mesma lei do resto — nada de procedimento inventado; o que não couber em "conceito + prática na sua DAW", vira texto honesto sem passo a passo específico.

---

## Sequência que eu recomendo (e começo ao confirmar)

1. **A1–A3** (código no sandbox → commits → zip novo pra você) — destrava tudo do trilho 1
2. Em paralelo, você: **grave as aulas do Curso 01** no seu ritmo (1/dia = free-course completo em ~2 semanas) e preencha `videoUrl` no `/admin` local
3. **Fase B** seus cliques num sábado → primeiro deploy real
4. **A4–A7** enquanto os primeiros alunos entram no demo público
5. Cursos 10–13 gerados por mim + sua revisão de especialista (você testa os procedimentos na sua DAW antes de eu marcar `verified` — é a regra, vale pra nós dois)
